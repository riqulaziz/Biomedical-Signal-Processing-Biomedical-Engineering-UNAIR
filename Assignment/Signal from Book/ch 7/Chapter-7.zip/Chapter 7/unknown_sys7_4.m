function y = unknown_sys7_4(x)
% Unknown system used in Problem 20 
%
N = length(x);
w = (1:N);
w1 = 15;            % First-order cufoff freq (rad)
w2 =  40;              % Second-order resonant freq.
w3 = 2000;
X = fft(x);
% Define transfer function
TF = 10*(1+j*w/w1)./((1+j*w/w2).*(1+j*w/w3));
Y1 = X .* TF;
y = real(ifft(Y1));
y = 2*y;                % Correct for fft scaling
