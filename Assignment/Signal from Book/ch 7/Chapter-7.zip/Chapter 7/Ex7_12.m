% Ex  7.12 Comparison of time and frequency characteristics of a second-order system
%   with different damping factors. 
%
clear all; close all;
w = 1:1:10000;                     		% Frequency vector: 1 to 10,000 rad/sec
t = 0:.0001:.4;                         		% Time vector: 0 to 0.4 sec.
delta = [0.5 0.1 0.05];                 		% Damping factors
% Calculate spectra
hold on;                            	% Plot superimposed
for k = 1:length(delta)                                  % Repeat for each damping factor
    TF = 1./(1 - 10.^-4*w.^2 + 1i*delta(k)*.02*w);    % Transfer function
    Mag = 20*log10(abs(TF));                       	% Take magnitude in dB
    semilogx(w, Mag,'k');  			% Plot semilog (log frequency)
end
xlabel('Frequency (rad/sec)','FontSize',14); 
ylabel('V_o_u_t (\omega) (dB)','FontSize',14);
grid on;
% Calculate and plot time characteristics
figure ; hold on;				% Plot superimposed
wn = 100;                           			% Undamped natural frequency
for k = 1:length(delta)
    c = sqrt(1-delta(k)^2);			% Useful constant
    theta = atan(c/delta(k));		% Calculate theta
    xt = (1 - (1/c)*(exp(-delta(k)*wn*t)).*(sin(wn*c*t + theta)))/1000;  % Time function
    plot(t,xt,'k');
end
xlabel('Time (sec)','FontSize',14); ylabel('v_o_u_t(t)','FontSize',14);