% Ex  7.8 A biomechanics experiment that provides an
% underdamped second-order responsd
%   Plot the time response
%
close all; clear all;
t = 0:.001:2;                         % TIme vector
theta = 0.173*exp(-3*t).* sin(17.3*t);  % Solve eq. 
theta = theta*360/(2*pi);       % Convert to deg
plot(t,theta,'k'); hold on;
plot([-.2 t(end)],[0 0],'k');
%
 xlabel('Time (sec)','FontSize',14);
 ylabel('\theta (t) (deg)','FontSize',14);
 xlim([-.2 2])
