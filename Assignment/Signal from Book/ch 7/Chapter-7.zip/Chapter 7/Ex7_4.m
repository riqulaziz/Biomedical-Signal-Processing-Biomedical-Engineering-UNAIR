% Ex 7.4 First-order step and impulse response for two time constants
%
clear all; close all;

t = 0:.1:100;           % Time vector 0 to 100 min
subplot(1,2,1);
x = 250*exp(-0.05*t); 
plot(t,x,'k'); 
xlabel('Time (min)','FontSize',14); ylabel('P_A (mmHg)','FontSize',14);
title('Impulse Response','FontSize',14);
subplot(1,2,2);
x = 20*(1-exp(-0.05*t)); 
plot(t,x,'k'); 
xlabel('Time (min)','FontSize',14); ylabel('P_A (mmHg)','FontSize',14);
title('Step Response','FontSize',14);
        