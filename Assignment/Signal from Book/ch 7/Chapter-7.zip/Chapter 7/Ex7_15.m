% Example 7.15 Identify a biological system from input/output data.
%
clear all, close all;
% Generate input (filtereded impuse response
N = 2000;           % Data length
x = [ones(1,5), zeros(1,N-5)];   % Input signal Pulse
[y, spec] = unknown_sys7_3(x);  % Generate output
save bio_sys x y spec;
load bio_sys;
fs = 150;           % Sample frequency
N = length(x);      % Signal length
N_2 = round(N/2);   % Half signal length for fft
f = (1:N)*fs/N;     % Frequecny vector for plotting
X = abs(fft(x));    % Fourier transformof the input signal
Y = abs(fft(y));    % Fourier transformof the output signal
plot(f(1:N_2),X(1:N_2),':k'); hold on;
plot(f(1:N_2),Y(1:N_2),'k');
xlabel('Frequency(Hz)','FontSize',14); ylabel('Magnitude','FontSize',14); 
figure;
TF = Y./X;          % Calculate magnitude transfer function
TF_dB = 20*log10(TF);   % in dB
semilogx(f(1:N_2),TF_dB(1:N_2),'k'); hold on;
semilogx(f(1:N_2),spec(1:N_2),':k','LineWidth',2);
xlabel('Frequency(Hz)','FontSize',14); ylabel('Magnitude (dB)','FontSize',14); 
%ylim([-20 5]); 
grid on;
% check identification

w = 2*pi*f;         % Freuency vector in Hz
TF = j*w./((1+ j*0.794*w).*(1 + j*.032*w));
Mag = 20*log10(abs(TF));
semilogx(f(1:N_2),Mag(1:N_2),':b','LineWidth',2);
xlabel('Frequency(Hz)','FontSize',14); ylabel('Magnitude (dB)','FontSize',14); 
