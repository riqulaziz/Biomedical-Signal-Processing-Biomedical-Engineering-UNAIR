% Example 7.9 Find the Bode plot (magnitude and phase) of the transfer 
%  function below.  Use MATLAB to factor the numerator and denominator 
%  and generate the Bode plot. Also expand the transfer function using the MATLAB 
%  partial fracion expansion routine
clear all; close all;
% 
% Define numerator and denominator
num = [1 5 3 10];         % Define numerator polynomial
den = [1 12 20 14 10];     % Define denominator polynomial
n_root = roots(num)           % Factor numerator and display
d_root = roots(den)           % Factor demoninator and display
%  Expand the ploynomial 
%
nun_sec_ord = poly([-0.0957+j*1.4389,-0.0957-j*1.4389])  % Construct 2nd-order numerator 
den_sec_order = poly([-0.2073+j*0.8039,-0.2073-j*0.8039]) %Construct 2nd-order denominator
%
% Plot the Bode Plot
w = 0.1:.05:100;
TF = (j*w + 4.81).*(-w.^2+j*0.19*w + 2.08)...
    ./((j*w +10.2).*(j*w+1.43).*(-w.^2+j*0.41*w+0.69));
subplot(2,1,1);
semilogx(w,20*log10(abs(TF)),'k','LineWidth',1);
xlabel('Frequency (rad/sec)','FontSize',14); ylabel('|TF (dB)|','FontSize',14); grid on;
subplot(2,1,2);
semilogx(w,unwrap(angle(TF))*360/(2*pi),'k','LineWidth',1);
xlabel('Frequency (rad/sec)','FontSize',14); ylabel('Phase (deg)','FontSize',14); 
ylim([-180 0]); grid on;