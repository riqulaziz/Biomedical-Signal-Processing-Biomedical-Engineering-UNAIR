% Ex 7.7  Find the step response using MATLAB to find the roots.
b =  0.25;     % Numerator coeefficients
a = [1 15 50];  % Denominator coefficcients
[numerator, rootss, const] = residue(b,a)
