function y = unknown_sys7_1(x)
% Unknown system used in Example 7.13
%
N = length(x);
w = (1:N);
w1 = 10;            % First-order cufoff freq (rad)
wn = 500;              % Second-order resonant freq.
delta = 0.1;         % Damping factor
X = fft(x);
% Define transfer function
TF = 100*(1+j*w/w1)./(j*w.*(1 - (w/wn).^2 + j*2*delta*w/wn));
Y1 = X .* TF;
y = real(ifft(Y1));
y = 2*y;                % Correct for fft scaling
