% Prob 21 Idneitifies an unknown process termed unknown_sys7_5
%  using sine waves. 
%
clear all; close all;
N = 1000;  % Input signal length
t = (0:N-1);                                  % Time vector 
for k = 1:400                                   % Try frequencies up to 100 Hz
  f(k) = k;                                     % Freq = k = 1-100Hz
  x = 1.414* cos(2*pi*f(k)*t);                  % Sinusoid with RMS = 1.0
  y = unknown_sys7_2(x);                        % Input stimulus to process
  Y(k) = sqrt(mean(y.^2));                      % Calculate RMS value as magnitude
end
Y = 20*log10(Y);                                % Convert to dB
x1 = [1, zeros(1,N-1)];                         % Generate impulse response
[y1, spec] = unknown_sys7_2(x1);                % Get impulse response
Mag = abs(fft(y1));                             % Get magnitude spectrum
Y1 = 20*log10(Mag(1:400));                      % Convert to dB
semilogx(f,Y,'k','LineWidth',1); hold on;       % Plot magnitude as dB/log f
semilogx(f,Y1,':k','LineWidth',2);              % Plot as dB/log f
semilogx(f,spec(1:400),'--k','LineWidth',2);    % Plot as log f (Actual sepetrum in dB)
xlabel('Frequency (Hz)','FontSize',14);
ylabel('Magnitude (dB)','FontSize',14);
%figure 
% Check identification
w = 2*pi*f;             % Define frequency vector in rad
TF = 1./((1+j*0.0159*w).*(1+j*.002*w));
Mag = 20*log10(abs(TF)); % Convert to dB 
plot(f,Mag,'--k','LineWidth',2);                % Plot magnitude as dB/log f
xlabel('Frequency (Hz)','FontSize',14);
ylabel('Magnitude (dB)','FontSize',14);
ylim([-70 5]);
grid on;

