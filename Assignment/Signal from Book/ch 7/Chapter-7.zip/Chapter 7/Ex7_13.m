% Example 7.13  Use MATLAB to find the transfer function of an unknown
%  system given input and output signals.
%
clear all; close all;
fs = 1000;           % Assumed sample rate
N = 10000;            % Number of points
f = (0:N-1)*fs/N;    % Frequency vector for plotting     
t = (1:N)/fs;        % Time vector for plotting
nf = round(N/2);     % Plot only first half of spectra
x = rand(1,N);       % Input signal
y = unknown_sys7_1(x);  % System
X = fft(x);          % Convert input to freq domain0
Y = fft(y);          % Convert output to freq. domain
TF = Y./X;           % Find TF
Mag = 20*log10(abs(TF));  % TF in dB
% Plot
 semilogx(f(1:nf),Mag(1:nf),'k'); hold on;
 xlabel('Frequency (Hz)','FontSize',14);
  ylabel('|TF({\it\omega})| (dB)','FontSize',14);
 grid on;
 % Check result
 w = 2*pi*f(1:nf);
 TF = 10*(1+j*0.8*w)./(j*w.*(1-(.0032*w).^2+ j*.00064*w));
 Mag = 20*log10(abs(TF));
 semilogx(w/(2*pi),Mag,':k');
      