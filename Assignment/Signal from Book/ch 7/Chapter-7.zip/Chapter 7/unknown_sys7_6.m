function y = unknown_sys7_6(x)
% Unknown system used in Problem 22
%
N = length(x);
w = (1:N);
w1 = 2;            % First-order cufoff freq (rad)
w2 = 300;              % Second-order resonant freq.
X = fft(x);
% Define transfer function
TF = 10*(1+j*w/w1)./(j*w.*(1+j*w/w2));
Y1 = X .* TF;
y = real(ifft(Y1));
y = 2*y;                % Correct for fft scaling
