function [y, spec] = unknown_sys7_3(x)
% Unknown system used in Example 7.15
%
N = length(x);
w = (1:N);
w1 = 2;            % First-order cufoff freq (rad)
w2 = 70;              % First -order cutoff resonant freq.
X = fft(x);
% Define transfer function
TF =.5*w./((1+j*w/w1).*(1+j*w/w2));
Y1 = X .* TF;
y = real(ifft(Y1));
y = 2*y;                % Correct for fft scaling
spec = 20*log10(abs(TF));