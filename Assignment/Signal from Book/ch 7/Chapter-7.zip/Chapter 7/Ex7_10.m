% Ex  7.10 Initial condition problem
%   Plot the time response
%
close all; clear all;
t = 0:1:1200;  % TIme vector 
A = .7;
K = .01;
V = 3;
c0 = 25;
c1 = (A/K)*(1-exp(-t*K/V));
c2 = c0*exp(-t*K/V);
c = c1 + c2;
plot(t,c1,'k'); hold on;
plot(t,c2,'k');
plot(t,c,'k','LineWidth',2);

 xlabel('Time (sec)','FontSize',14);
 ylabel('c(t)','FontSize',14);
