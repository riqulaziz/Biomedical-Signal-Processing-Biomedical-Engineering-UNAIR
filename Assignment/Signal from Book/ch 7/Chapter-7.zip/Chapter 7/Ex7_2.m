% Example 7.2  Use MATLAB to plot the transfer function of 2 time delays 
%
clear all; close all;
T = 2;                                          % Time delay in sec. 
w = .1:1:100;                      % Frequency vector 
TF = exp(-j*T*w);                       % Transfer function
Mag = 20*log10(abs(TF));            % Calcuate magnitude spectrum
Phase = unwrap(angle(TF))*360/(2*pi);       % Calculate phase spectrum
clear TF T;
T = .5;                                          % Time delay in sec. 
TF = exp(-j*T*w);                       % Transfer function
Mag1 = 20*log10(abs(TF));            % Calcuate magnitude spectrum
Phase1 = unwrap(angle(TF))*360/(2*pi);       % Calculate phase spectrum
subplot(2,1,1); hold on;
  plot(w,Mag,'k');
  plot(w,Mag1,':k','LineWidth',2);
  xlabel('Frequency (rad/sec)','FontSize',14);
  ylabel('|TF({\it\omega})| (dB)','FontSize',14);
  axis([w(1) w(end) -1 1]);
subplot(2,1,2); hold on;
  plot(w,Phase,'k');
  plot(w,Phase1,':k','LineWidth',2);
  xlabel('Frequency (rad/sec)','FontSize',14);
  ylabel('Phase({\it\omega}) (deg)','FontSize',14);  